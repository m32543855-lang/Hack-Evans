"use client"

import { useState, useEffect } from "react"
import { 
  Search, Filter, BookOpen, Clock, Users, Star, Play, 
  ChevronRight, Award, TrendingUp, Lock, CheckCircle,
  Calculator, Brain, Beaker, Languages, Globe, Monitor,
  GraduationCap, FileText, Sparkles
} from "lucide-react"
import { cn } from "@/lib/utils"

const CATEGORIES = [
  { id: "todos", label: "Todos", icon: Sparkles },
  { id: "razonamiento", label: "Razonamiento", icon: Calculator },
  { id: "pedagogia", label: "Pedagogia", icon: Brain },
  { id: "educacion-inicial", label: "Educacion Inicial", icon: GraduationCap },
  { id: "ciencias", label: "Ciencias", icon: Beaker },
  { id: "matematicas", label: "Matematicas", icon: Calculator },
  { id: "idiomas", label: "Idiomas", icon: Languages },
  { id: "humanidades", label: "Humanidades", icon: Globe },
  { id: "digital", label: "Digital", icon: Monitor },
  { id: "sime", label: "SIME / Magisterio", icon: FileText },
  { id: "evaluacion", label: "Evaluacion", icon: Award },
]

const COURSES = [
  {
    id: 1,
    title: "Razonamiento Logico Matematico",
    description: "Domina los conceptos clave de razonamiento numerico y logico para el examen QSM",
    category: "razonamiento",
    duration: "24 horas",
    lessons: 48,
    students: 3420,
    rating: 4.9,
    instructor: "Dr. Carlos Mendez",
    price: 49.99,
    popular: true,
    progress: 0,
    locked: false,
    color: "from-red-600 to-red-800",
    icon: Calculator,
  },
  {
    id: 2,
    title: "Geometria y Medicion",
    description: "Aprende geometria plana, espacial y medicion de manera practica",
    category: "matematicas",
    duration: "18 horas",
    lessons: 36,
    students: 2150,
    rating: 4.8,
    instructor: "Lic. Maria Torres",
    price: 39.99,
    popular: true,
    progress: 45,
    locked: false,
    color: "from-amber-600 to-orange-700",
    icon: GraduationCap,
  },
  {
    id: 3,
    title: "Saberes Pedagogicos Fundamentales",
    description: "Domina los fundamentos de pedagogia y didactica para tu evaluacion",
    category: "pedagogia",
    duration: "32 horas",
    lessons: 64,
    students: 4200,
    rating: 4.9,
    instructor: "Dra. Ana Lucia Paredes",
    price: 59.99,
    popular: true,
    progress: 100,
    locked: false,
    color: "from-emerald-600 to-green-700",
    icon: Brain,
  },
  {
    id: 4,
    title: "Comprension Lectora Avanzada",
    description: "Mejora tu velocidad y comprension de lectura para excelentes resultados",
    category: "razonamiento",
    duration: "16 horas",
    lessons: 32,
    students: 2890,
    rating: 4.7,
    instructor: "Lic. Roberto Vaca",
    price: 34.99,
    popular: false,
    progress: 0,
    locked: false,
    color: "from-blue-600 to-indigo-700",
    icon: BookOpen,
  },
  {
    id: 5,
    title: "Ciencias Naturales para Docentes",
    description: "Preparacion completa en biologia, quimica y fisica para el examen",
    category: "ciencias",
    duration: "28 horas",
    lessons: 56,
    students: 1680,
    rating: 4.8,
    instructor: "Dr. Luis Andrade",
    price: 54.99,
    popular: false,
    progress: 0,
    locked: true,
    color: "from-cyan-600 to-teal-700",
    icon: Beaker,
  },
  {
    id: 6,
    title: "Ingles para Educadores",
    description: "Domina el ingles necesario para la evaluacion docente",
    category: "idiomas",
    duration: "40 horas",
    lessons: 80,
    students: 3100,
    rating: 4.6,
    instructor: "Prof. Sarah Williams",
    price: 69.99,
    popular: false,
    progress: 20,
    locked: false,
    color: "from-violet-600 to-purple-700",
    icon: Languages,
  },
  {
    id: 7,
    title: "Educacion Inicial y Preescolar",
    description: "Estrategias didacticas especializadas para educacion inicial",
    category: "educacion-inicial",
    duration: "22 horas",
    lessons: 44,
    students: 1950,
    rating: 4.9,
    instructor: "Lic. Carmen Silva",
    price: 44.99,
    popular: true,
    progress: 0,
    locked: false,
    color: "from-pink-500 to-rose-600",
    icon: GraduationCap,
  },
  {
    id: 8,
    title: "Tecnologia Educativa Digital",
    description: "Herramientas digitales y recursos tecnologicos para el aula moderna",
    category: "digital",
    duration: "20 horas",
    lessons: 40,
    students: 2340,
    rating: 4.7,
    instructor: "Ing. Pablo Ruiz",
    price: 39.99,
    popular: false,
    progress: 0,
    locked: true,
    color: "from-slate-600 to-gray-700",
    icon: Monitor,
  },
  {
    id: 9,
    title: "Historia y Geografia del Ecuador",
    description: "Conocimiento integral de la historia y geografia nacional",
    category: "humanidades",
    duration: "26 horas",
    lessons: 52,
    students: 1420,
    rating: 4.8,
    instructor: "Dr. Fernando Espinoza",
    price: 49.99,
    popular: false,
    progress: 0,
    locked: false,
    color: "from-yellow-600 to-amber-700",
    icon: Globe,
  },
  {
    id: 10,
    title: "Preparacion SIME Completa",
    description: "Curso integral para el Sistema de Informacion del Ministerio de Educacion",
    category: "sime",
    duration: "30 horas",
    lessons: 60,
    students: 2780,
    rating: 4.9,
    instructor: "Msc. Diana Coronel",
    price: 64.99,
    popular: true,
    progress: 0,
    locked: false,
    color: "from-red-500 to-rose-700",
    icon: FileText,
  },
  {
    id: 11,
    title: "Evaluacion Docente 2026",
    description: "Todo lo que necesitas saber sobre el proceso de evaluacion docente",
    category: "evaluacion",
    duration: "14 horas",
    lessons: 28,
    students: 4500,
    rating: 4.9,
    instructor: "Equipo Hack Evans",
    price: 29.99,
    popular: true,
    progress: 0,
    locked: false,
    color: "from-emerald-500 to-green-600",
    icon: Award,
  },
  {
    id: 12,
    title: "Matematicas para Educacion Basica",
    description: "Conceptos matematicos esenciales para docentes de educacion basica",
    category: "matematicas",
    duration: "24 horas",
    lessons: 48,
    students: 1890,
    rating: 4.7,
    instructor: "Lic. Jorge Palacios",
    price: 44.99,
    popular: false,
    progress: 0,
    locked: true,
    color: "from-orange-500 to-red-600",
    icon: Calculator,
  },
]

export default function CursosPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("todos")
  const [sortBy, setSortBy] = useState("popular")
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    setIsLoaded(true)
  }, [])

  const filteredCourses = COURSES.filter((course) => {
    const matchesSearch = 
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "todos" || course.category === selectedCategory
    return matchesSearch && matchesCategory
  }).sort((a, b) => {
    if (sortBy === "popular") return b.students - a.students
    if (sortBy === "rating") return b.rating - a.rating
    if (sortBy === "newest") return b.id - a.id
    if (sortBy === "price-low") return a.price - b.price
    if (sortBy === "price-high") return b.price - a.price
    return 0
  })

  return (
    <div className="p-6 lg:p-8 space-y-8">
      {/* Header */}
      <div className={cn(
        "text-center space-y-4 transition-all duration-700",
        isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
      )}>
        <p className="text-[#E8392A] font-semibold tracking-wider text-sm uppercase">
          Catalogo de Cursos
        </p>
        <h1 className="text-3xl md:text-4xl font-bold text-foreground">
          Explora Nuestros <span className="text-[#E8392A]">Cursos</span>
        </h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Accede a contenido especializado para tu preparacion docente
        </p>
      </div>

      {/* Search and Filters */}
      <div className={cn(
        "space-y-4 transition-all duration-700 delay-100",
        isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
      )}>
        <div className="flex flex-col md:flex-row gap-4">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Buscar por area, nivel o tema..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-card border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-[#E8392A]/50 focus:border-[#E8392A] transition-all"
            />
          </div>

          {/* Sort */}
          <div className="flex items-center gap-3">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-4 py-3 bg-card border border-border rounded-xl text-foreground focus:outline-none focus:ring-2 focus:ring-[#E8392A]/50 focus:border-[#E8392A] transition-all cursor-pointer"
            >
              <option value="popular">Mas populares</option>
              <option value="rating">Mejor valorados</option>
              <option value="newest">Mas recientes</option>
              <option value="price-low">Precio: menor a mayor</option>
              <option value="price-high">Precio: mayor a menor</option>
            </select>
            <span className="text-muted-foreground whitespace-nowrap">
              {filteredCourses.length} cursos
            </span>
          </div>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap gap-2">
          {CATEGORIES.map((category) => {
            const Icon = category.icon
            return (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all duration-300",
                  selectedCategory === category.id
                    ? "bg-[#E8392A] text-white shadow-lg shadow-[#E8392A]/25"
                    : "bg-card border border-border text-foreground hover:border-[#E8392A]/50 hover:text-[#E8392A]"
                )}
              >
                <Icon className="w-4 h-4" />
                {category.label}
              </button>
            )
          })}
        </div>
      </div>

      {/* Course Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCourses.map((course, index) => {
          const Icon = course.icon
          return (
            <div
              key={course.id}
              className={cn(
                "group relative bg-card border border-border rounded-2xl overflow-hidden hover:border-[#E8392A]/50 transition-all duration-500 hover:shadow-xl hover:shadow-[#E8392A]/10 hover:-translate-y-1",
                isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              )}
              style={{ transitionDelay: `${150 + index * 50}ms` }}
            >
              {/* Course Header Image */}
              <div className={cn(
                "relative h-36 bg-gradient-to-br flex items-center justify-center",
                course.color
              )}>
                <Icon className="w-16 h-16 text-white/80" />
                
                {/* Badges */}
                <div className="absolute top-3 right-3 flex gap-2">
                  {course.popular && (
                    <span className="flex items-center gap-1 px-2 py-1 bg-[#E8392A] text-white text-xs font-bold rounded-full">
                      <TrendingUp className="w-3 h-3" />
                      Popular
                    </span>
                  )}
                  {course.locked && (
                    <span className="flex items-center gap-1 px-2 py-1 bg-black/50 text-white text-xs font-bold rounded-full">
                      <Lock className="w-3 h-3" />
                      Premium
                    </span>
                  )}
                </div>

                {/* Progress indicator */}
                {course.progress > 0 && (
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/30">
                    <div 
                      className="h-full bg-[#22c55e] transition-all duration-500"
                      style={{ width: `${course.progress}%` }}
                    />
                  </div>
                )}
              </div>

              {/* Course Content */}
              <div className="p-5 space-y-4">
                <div>
                  <h3 className="font-bold text-foreground group-hover:text-[#E8392A] transition-colors line-clamp-1">
                    {course.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                    {course.description}
                  </p>
                </div>

                {/* Stats */}
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    {course.duration}
                  </span>
                  <span className="flex items-center gap-1">
                    <BookOpen className="w-3.5 h-3.5" />
                    {course.lessons} lecciones
                  </span>
                  <span className="flex items-center gap-1">
                    <Users className="w-3.5 h-3.5" />
                    {course.students.toLocaleString()}
                  </span>
                </div>

                {/* Rating & Price */}
                <div className="flex items-center justify-between pt-3 border-t border-border">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-[#F5C842] fill-[#F5C842]" />
                    <span className="font-semibold text-foreground">{course.rating}</span>
                  </div>

                  {course.progress === 100 ? (
                    <span className="flex items-center gap-1 text-[#22c55e] font-semibold text-sm">
                      <CheckCircle className="w-4 h-4" />
                      Completado
                    </span>
                  ) : course.progress > 0 ? (
                    <span className="text-[#E8392A] font-semibold text-sm">
                      {course.progress}% completado
                    </span>
                  ) : (
                    <span className="text-[#E8392A] font-bold">
                      ${course.price}
                    </span>
                  )}
                </div>

                {/* Action Button */}
                <button className={cn(
                  "w-full flex items-center justify-center gap-2 py-2.5 rounded-xl font-semibold text-sm transition-all duration-300",
                  course.progress === 100
                    ? "bg-[#22c55e]/10 text-[#22c55e] hover:bg-[#22c55e]/20"
                    : course.progress > 0
                    ? "bg-[#E8392A] text-white hover:bg-[#E8392A]/90"
                    : course.locked
                    ? "bg-secondary text-muted-foreground cursor-not-allowed"
                    : "bg-[#E8392A]/10 text-[#E8392A] hover:bg-[#E8392A] hover:text-white"
                )}>
                  {course.progress === 100 ? (
                    <>
                      <Award className="w-4 h-4" />
                      Ver certificado
                    </>
                  ) : course.progress > 0 ? (
                    <>
                      <Play className="w-4 h-4" />
                      Continuar curso
                    </>
                  ) : course.locked ? (
                    <>
                      <Lock className="w-4 h-4" />
                      Desbloquear
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4" />
                      Iniciar curso
                      <ChevronRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </div>
          )
        })}
      </div>

      {/* Empty State */}
      {filteredCourses.length === 0 && (
        <div className="text-center py-16">
          <BookOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-xl font-bold text-foreground mb-2">No se encontraron cursos</h3>
          <p className="text-muted-foreground">
            Intenta cambiar los filtros o buscar con otros terminos
          </p>
        </div>
      )}
    </div>
  )
}
