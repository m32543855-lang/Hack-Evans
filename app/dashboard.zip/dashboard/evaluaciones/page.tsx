"use client"

import { useState, useEffect } from "react"
import { 
  FileText, Clock, Trophy, Target, CheckCircle, XCircle,
  Calendar, BarChart3, Award, Play, Lock, ChevronRight,
  AlertCircle, Users, Star, Timer, ArrowRight
} from "lucide-react"
import { cn } from "@/lib/utils"

const EVALUACIONES = [
  {
    id: 1,
    title: "Evaluacion Diagnostica QSM 10",
    description: "Evaluacion inicial para conocer tu nivel actual de preparacion",
    type: "diagnostico",
    questions: 50,
    duration: 60,
    attempts: 3,
    maxAttempts: 3,
    bestScore: 78,
    passingScore: 70,
    status: "completed",
    category: "QSM",
    difficulty: "Intermedio",
  },
  {
    id: 2,
    title: "Examen Parcial - Saberes Pedagogicos",
    description: "Evaluacion de conocimientos en pedagogia y didactica",
    type: "parcial",
    questions: 40,
    duration: 45,
    attempts: 1,
    maxAttempts: 2,
    bestScore: 85,
    passingScore: 70,
    status: "completed",
    category: "Pedagogia",
    difficulty: "Avanzado",
  },
  {
    id: 3,
    title: "Simulacro Nacional QSM 2026",
    description: "Simulacro completo con condiciones reales del examen oficial",
    type: "simulacro",
    questions: 120,
    duration: 180,
    attempts: 0,
    maxAttempts: 1,
    bestScore: null,
    passingScore: 75,
    status: "available",
    category: "QSM",
    difficulty: "Avanzado",
    featured: true,
  },
  {
    id: 4,
    title: "Evaluacion - Razonamiento Logico",
    description: "Prueba tus habilidades de razonamiento logico y matematico",
    type: "parcial",
    questions: 30,
    duration: 40,
    attempts: 2,
    maxAttempts: 3,
    bestScore: 92,
    passingScore: 70,
    status: "completed",
    category: "Razonamiento",
    difficulty: "Intermedio",
  },
  {
    id: 5,
    title: "Evaluacion Final - Modulo 1",
    description: "Evaluacion final del primer modulo de preparacion",
    type: "final",
    questions: 60,
    duration: 90,
    attempts: 0,
    maxAttempts: 1,
    bestScore: null,
    passingScore: 80,
    status: "locked",
    category: "General",
    difficulty: "Avanzado",
    unlockDate: "2026-04-15",
  },
  {
    id: 6,
    title: "Mini Test - Comprension Lectora",
    description: "Evaluacion rapida de comprension lectora",
    type: "mini",
    questions: 15,
    duration: 20,
    attempts: 0,
    maxAttempts: 5,
    bestScore: null,
    passingScore: 60,
    status: "available",
    category: "Razonamiento",
    difficulty: "Basico",
  },
]

const STATS = [
  { label: "Evaluaciones Completadas", value: "8", icon: CheckCircle, color: "text-[#22c55e]" },
  { label: "Promedio General", value: "85%", icon: BarChart3, color: "text-[#E8392A]" },
  { label: "Mejor Puntuacion", value: "92%", icon: Trophy, color: "text-[#F5C842]" },
  { label: "Tiempo Total", value: "12h 30m", icon: Clock, color: "text-blue-500" },
]

export default function EvaluacionesPage() {
  const [filter, setFilter] = useState("all")
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    setIsLoaded(true)
  }, [])

  const filteredEvaluaciones = EVALUACIONES.filter((ev) => {
    if (filter === "all") return true
    if (filter === "available") return ev.status === "available"
    if (filter === "completed") return ev.status === "completed"
    if (filter === "locked") return ev.status === "locked"
    return true
  })

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <span className="flex items-center gap-1 px-2 py-1 bg-[#22c55e]/10 text-[#22c55e] text-xs font-semibold rounded-full">
            <CheckCircle className="w-3 h-3" />
            Completada
          </span>
        )
      case "available":
        return (
          <span className="flex items-center gap-1 px-2 py-1 bg-[#E8392A]/10 text-[#E8392A] text-xs font-semibold rounded-full">
            <Play className="w-3 h-3" />
            Disponible
          </span>
        )
      case "locked":
        return (
          <span className="flex items-center gap-1 px-2 py-1 bg-secondary text-muted-foreground text-xs font-semibold rounded-full">
            <Lock className="w-3 h-3" />
            Bloqueada
          </span>
        )
      default:
        return null
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "diagnostico":
        return <Target className="w-5 h-5" />
      case "parcial":
        return <FileText className="w-5 h-5" />
      case "simulacro":
        return <Award className="w-5 h-5" />
      case "final":
        return <Trophy className="w-5 h-5" />
      case "mini":
        return <Timer className="w-5 h-5" />
      default:
        return <FileText className="w-5 h-5" />
    }
  }

  return (
    <div className="p-6 lg:p-8 space-y-8">
      {/* Header */}
      <div className={cn(
        "text-center space-y-4 transition-all duration-700",
        isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
      )}>
        <p className="text-[#E8392A] font-semibold tracking-wider text-sm uppercase">
          Centro de Evaluaciones
        </p>
        <h1 className="text-3xl md:text-4xl font-bold text-foreground">
          Evalua tu <span className="text-[#E8392A]">Progreso</span>
        </h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Realiza evaluaciones y simulacros para medir tu avance
        </p>
      </div>

      {/* Stats */}
      <div className={cn(
        "grid grid-cols-2 lg:grid-cols-4 gap-4 transition-all duration-700 delay-100",
        isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
      )}>
        {STATS.map((stat, index) => {
          const Icon = stat.icon
          return (
            <div
              key={index}
              className="bg-card border border-border rounded-xl p-4 hover:border-[#E8392A]/30 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className={cn("p-2 rounded-lg bg-secondary", stat.color)}>
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Filters */}
      <div className={cn(
        "flex flex-wrap gap-2 transition-all duration-700 delay-200",
        isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
      )}>
        {[
          { id: "all", label: "Todas" },
          { id: "available", label: "Disponibles" },
          { id: "completed", label: "Completadas" },
          { id: "locked", label: "Bloqueadas" },
        ].map((f) => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            className={cn(
              "px-4 py-2 rounded-full text-sm font-medium transition-all",
              filter === f.id
                ? "bg-[#E8392A] text-white"
                : "bg-card border border-border text-foreground hover:border-[#E8392A]/50"
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Evaluaciones Grid */}
      <div className="space-y-4">
        {filteredEvaluaciones.map((ev, index) => (
          <div
            key={ev.id}
            className={cn(
              "group bg-card border border-border rounded-xl p-5 hover:border-[#E8392A]/50 transition-all duration-500",
              ev.featured && "ring-2 ring-[#E8392A] ring-offset-2 ring-offset-background",
              isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
            )}
            style={{ transitionDelay: `${200 + index * 50}ms` }}
          >
            <div className="flex flex-col lg:flex-row lg:items-center gap-4">
              {/* Icon & Info */}
              <div className="flex items-start gap-4 flex-1">
                <div className={cn(
                  "p-3 rounded-xl",
                  ev.status === "completed" ? "bg-[#22c55e]/10 text-[#22c55e]" :
                  ev.status === "available" ? "bg-[#E8392A]/10 text-[#E8392A]" :
                  "bg-secondary text-muted-foreground"
                )}>
                  {getTypeIcon(ev.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-bold text-foreground">{ev.title}</h3>
                    {getStatusBadge(ev.status)}
                    {ev.featured && (
                      <span className="flex items-center gap-1 px-2 py-1 bg-[#F5C842]/10 text-[#F5C842] text-xs font-semibold rounded-full">
                        <Star className="w-3 h-3" />
                        Destacado
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">{ev.description}</p>
                  
                  {/* Meta */}
                  <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <FileText className="w-3.5 h-3.5" />
                      {ev.questions} preguntas
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      {ev.duration} min
                    </span>
                    <span className="flex items-center gap-1">
                      <Target className="w-3.5 h-3.5" />
                      Aprobar: {ev.passingScore}%
                    </span>
                    <span className="px-2 py-0.5 bg-secondary rounded-full">
                      {ev.category}
                    </span>
                  </div>
                </div>
              </div>

              {/* Score & Action */}
              <div className="flex items-center gap-4 lg:gap-6">
                {ev.status === "completed" && ev.bestScore !== null && (
                  <div className="text-center">
                    <div className={cn(
                      "text-2xl font-bold",
                      ev.bestScore >= ev.passingScore ? "text-[#22c55e]" : "text-[#E8392A]"
                    )}>
                      {ev.bestScore}%
                    </div>
                    <div className="text-xs text-muted-foreground">Mejor puntaje</div>
                    <div className="text-xs text-muted-foreground">
                      {ev.attempts}/{ev.maxAttempts} intentos
                    </div>
                  </div>
                )}

                {ev.status === "locked" && ev.unlockDate && (
                  <div className="text-center">
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <Calendar className="w-4 h-4" />
                      <span className="text-sm">
                        {new Date(ev.unlockDate).toLocaleDateString("es-ES", {
                          day: "numeric",
                          month: "short",
                        })}
                      </span>
                    </div>
                    <div className="text-xs text-muted-foreground">Disponible</div>
                  </div>
                )}

                <button
                  className={cn(
                    "flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-sm transition-all whitespace-nowrap",
                    ev.status === "available"
                      ? "bg-[#E8392A] text-white hover:bg-[#E8392A]/90"
                      : ev.status === "completed" && ev.attempts < ev.maxAttempts
                      ? "bg-[#E8392A]/10 text-[#E8392A] hover:bg-[#E8392A] hover:text-white"
                      : ev.status === "completed"
                      ? "bg-secondary text-muted-foreground"
                      : "bg-secondary text-muted-foreground cursor-not-allowed"
                  )}
                  disabled={ev.status === "locked" || (ev.status === "completed" && ev.attempts >= ev.maxAttempts)}
                >
                  {ev.status === "available" ? (
                    <>
                      Iniciar
                      <ArrowRight className="w-4 h-4" />
                    </>
                  ) : ev.status === "completed" && ev.attempts < ev.maxAttempts ? (
                    <>
                      Reintentar
                      <ChevronRight className="w-4 h-4" />
                    </>
                  ) : ev.status === "completed" ? (
                    <>
                      <CheckCircle className="w-4 h-4" />
                      Ver resultados
                    </>
                  ) : (
                    <>
                      <Lock className="w-4 h-4" />
                      Bloqueada
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {filteredEvaluaciones.length === 0 && (
        <div className="text-center py-16">
          <FileText className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-xl font-bold text-foreground mb-2">No hay evaluaciones</h3>
          <p className="text-muted-foreground">
            No se encontraron evaluaciones con los filtros seleccionados
          </p>
        </div>
      )}
    </div>
  )
}
